﻿select * from usuarios;

-- 'user', 'user01'
select * from usuarios where username = 'user';