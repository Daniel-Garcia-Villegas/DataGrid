﻿
CREATE TABLE [dbo].[usuario]
(
	[Id] INT NOT NULL identity(1,1) PRIMARY KEY,
	Username VARCHAR(50) NOT NULL,
	Password VARCHAR(50) NOT NULL,
	Nombre_Completo varchar(200)
);
select * from usuario;

insert into usuario(Username,Password,Nombre_Completo)
values ('administrador1','55555','Administrador');
insert into usuario(Username,Password,Nombre_Completo)
values ('user001','99999','Admooon');