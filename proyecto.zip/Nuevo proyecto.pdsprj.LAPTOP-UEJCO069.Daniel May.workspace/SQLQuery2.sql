﻿insert into usuarios(Username, Password, Nombre_Completo)
values ('administrador','nimda01','ADMINISTRADOR');
insert into usuarios(Username, Password, Nombre_Completo)
values ('user','user01','USUARIO');