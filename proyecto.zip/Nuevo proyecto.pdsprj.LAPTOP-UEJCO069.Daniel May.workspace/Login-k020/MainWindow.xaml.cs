﻿using Login_k020.Negocio;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Login_k020
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private LoginService login = new LoginService();


        public MainWindow()
        {
            InitializeComponent();
        }

        
        private void Button_Click(object sender, RoutedEventArgs e)
        {
  

            
        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            string username = varUsuario.Text;
            string password = varPBox.Password;
            
            if (login.checkContraBaseDatos(username,password))
            {

                //salidaLabel.Content = "Usuario logueado";
                //MessageBox.Show("Exito", "Usuario logueado");
                //Console.WriteLine("UserN: " + username + "PassW:" + password);
                MessageBox.Show("Usuario Logueado ");
                VentanaPrincipal ventanaPrincipal = new VentanaPrincipal();
                ventanaPrincipal.Show();
                this.Close();

                //this.Hide();


            }
            else
            {

                MessageBox.Show("Error de login","Usuario o password incorrectos");
                //salidaLabel.Content = "Usuario o password incorrectos";

            }

        }

        private void usernameTextbox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }


    }
}
