﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Login_k020
{
    /// <summary>
    /// Lógica de interacción para Productos.xaml
    /// </summary>
    public partial class Productos : Window
    {
      
        public Productos()
        {
            InitializeComponent();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            VentanaPrincipal sid = new VentanaPrincipal();
            sid.Show();
            this.Close();
        }
   

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            
            this.Close();
            
        }



        private void btn_N1_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show( "Productos = Ponchadoras" +
                "\nDescripcion = Pinzas Ponchadoras 3 En 1 Rj45 Rj11 Rj12 Pelador Rj45" +
                "\nCosto = $500");

        }

        private void btn_N2_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Producto = Conectores Rj45" +
                "\nDescripcion = Intellinet CN - 3024 Plug Rj45 Cat 5E UTP Solido 100 Pzas" +
                "\nCosto = $400");
        }

        private void btn_N3_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Producto = Capuchones" +
                "\nDescripcion = 100 Pz Bota Protectora Para Plug Rj45 Elige Colores Capuchón" +
                "\nCosto = $95");
        }

        private void btn_N4_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Producto = Tester" +
                "\nDescripcion = Probador Testeador Cable De Red Utp Rj11 Rj12 Rj45 Ethernet" +
                "\nCosto = $120");
        }

        private void btn_N5_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Producto = Rack" +
                "\nDescripcion = Kit de Organizador de Red Linkedpro KIT-ORG-24, Rack 24U, OrgVertical, Barra Contactos y Charola de 23 cms" +
                "\nCosto = $3,500");
        }

        private void btn_N6_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Producto = Switch" +
                "\nDescripcion = NETGEAR ProSAFE JGS524 24 - Port Gigabit Rackmount Switch 10/100/1000Mbps" +
                "\nCosto = $3,950");
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            Productos2 objM = new Productos2();
            objM.Show();
            this.Close();
        }
    }
}
