﻿namespace Login_k020.Datos
{
    public class Usuario
    {
        public string Username { get; set; }
        public string Password { get; set;}
        
    }
}