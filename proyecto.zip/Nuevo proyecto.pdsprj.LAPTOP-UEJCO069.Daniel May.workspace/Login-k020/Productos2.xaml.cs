﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Login_k020
{
    /// <summary>
    /// Lógica de interacción para Productos2.xaml
    /// </summary>
    public partial class Productos2 : Window
    {
        public Productos2()
        {
            InitializeComponent();
        }

        private void btn_N1_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Producto = Router" +
                "\nDescripcion = TP - Link AX5400 WiFi 6 Enrutador inalámbrico de Internet Gigabit de doble banda" +
                "\nCosto = $2, 819");
        }

        private void btn_N2_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Producto = Tarjeta de Red" +
                "\nDescripcion =Tarjeta de Red inalámbrica WiFi, Tarjeta de Red para Intel AX201NGW" +
                "\nCosto = $600");

        }

        private void btn_N3_Click(object sender, RoutedEventArgs e)
        {

            MessageBox.Show("Producto = Antena de Red" +
                "\nDescripcion = TP - Link | Adaptador USB Wifi de 1300 Mbps | Dongle de red inalámbrico MU - MIMO de doble banda" +
                "\nCosto = $400");

        }

        private void btn_N4_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Producto = UTP" +
                "\nDescripcion = Transmite 100 Mb/s | El precio mostrado es por metro" +
                "\nCosto = $15.00");
        }

        private void btn_N5_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Producto = Teclado Gamer " +
                "\nDescripcion =Iluminación, Teclado multimedia" +
                "\nCosto = $369");
        }

        private void btn_N6_Click(object sender, RoutedEventArgs e)
        {

            MessageBox.Show("Producto = Mouse Gamer" +
                "\nDescripcion =  Mouse Gamer CW905 Mouse Gaming 7 Botones Programables 6400" +
                "\nCosto = $399");
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            Productos vent = new Productos();
            vent.Show();
            this.Close();
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
