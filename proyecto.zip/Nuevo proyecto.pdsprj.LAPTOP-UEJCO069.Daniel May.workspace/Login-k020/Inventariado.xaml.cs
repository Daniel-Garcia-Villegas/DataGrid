﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Login_k020
{
    /// <summary>
    /// Lógica de interacción para Inventariado.xaml
    /// </summary>
    public partial class Inventariado : Window
    {
        public Inventariado()
        {
            InitializeComponent();
            List<catalogo> catalogo = new List<catalogo>();
            catalogo.Add(new catalogo()
            {
                Id = 1,
                ImageUrl = " ",
                Producto = "Ponchadora",
                Descripcion = "Pinzas Ponchadoras 3 En 1 Rj45 Rj11 Rj12 Pelador Rj45",
                Costo = "$500",
                Existencia = "2"
            });
            catalogo.Add(new catalogo()
            {
                Id = 2,
                Producto = "Conectores Rj45",
                Descripcion = "Intellinet CN-3024 Plug Rj45 Cat 5E UTP Solido 100 Pzas",
                Costo = "$400",
                Existencia = "7"
            });
            catalogo.Add(new catalogo()
            {
                Id = 3,
                Producto = "Capuchones",
                Descripcion = "100 Pz Bota Protectora Para Plug Rj45 Elige Colores Capuchón",
                Costo = "$95",
                Existencia = "4"
            });
            catalogo.Add(new catalogo()
            {
                Id = 4,
                Producto = "Tester",
                Descripcion = "Probador Testeador Cable De Red Utp Rj11 Rj12 Rj45 Ethernet",
                Costo = "$120",
                Existencia = "5"
            });
            catalogo.Add(new catalogo()
            {
                Id = 5,
                Producto = "Rack",
                Descripcion = "Kit de Organizador de Red Linkedpro KIT-ORG-24, Rack 24U, Org Vertical, Barra Contactos y Charola de 23 cms",
                Costo = "$3,500",
                Existencia = "10"
            });
            catalogo.Add(new catalogo()
            {
                Id = 6,
                Producto = "Switch",
                Descripcion = "NETGEAR ProSAFE JGS524 24-Port Gigabit Rackmount Switch 10/100/1000Mbps",
                Costo = "$3,950",
                Existencia = "20"
            });
            catalogo.Add(new catalogo()
            {
                Id = 7,
                Producto = "Router",
                Descripcion = "TP-Link AX5400 WiFi 6 Enrutador inalámbrico de Internet Gigabit de doble banda",
                Costo = "$2,819",
                Existencia = "30"
            });
            catalogo.Add(new catalogo()
            {
                Id = 8,
                Producto = "Tarjeta de Red",
                Descripcion = "Tarjeta de Red inalámbrica WiFi, Tarjeta de Red para Intel AX201NGW",
                Costo = "$600",
                Existencia = "80"
            });
            catalogo.Add(new catalogo()
            {
                Id = 9,
                Producto = "Antena de Red",
                Descripcion = "TP-Link | Adaptador USB Wifi de 1300 Mbps | Dongle de red inalámbrico MU-MIMO de doble banda",
                Costo = "$400",
                Existencia = "20"
            });

            dgUsers.ItemsSource = catalogo;
        }


        public class catalogo
        {
            public int Id { get; set; }

            public string Producto { get; set; }

            public string Descripcion { get; set; }

            public string Costo { get; set; }

            public string ImageUrl { get; set; }
            public string Existencia { get; set; }
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            VentanaPrincipal mostrarV = new VentanaPrincipal();
            mostrarV.Show();
            this.Close();
        }

        private void dgUsers_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {


        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            VentanaPrincipal vent1 = new VentanaPrincipal();
            vent1.Show();
            this.Close();
        }
    }
}
